

<?php $__env->startSection('title', 'Quality Metrics'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <br><br><br><br><br><br><br><br>
        <div class="col s4"></div>
        <div class="col s4 z-depth-2 grey darken-4">            
            <form method="POST" action="<?php echo e(route('add.empresa.bd')); ?>">
            <?php echo csrf_field(); ?>

                <div class="col s12 center">
                    <br>
                    <img src="https://www.qualitymetrics.cl/img/logo-header.png" class="responsive-img">
                </div>
                <div class="col s12">
                    <h6 class="white-text center">Registrar Empresa</h6>
                    <br><br><br>
                </div>

                <div class="input-field col s12 white-text">
                    <input  id="first_name" type="text" class="validate white-text" value="<?php echo e(old('name')); ?>" name="name" required autofocus autocomplete="name">
                    <label class="white-text" for="first_name" value="<?php echo e(__('Nombre de la Empresa')); ?>"><?php echo e(__('Nombre de la Empresa')); ?></label>
                </div>
                <div class="col s12 center">
                    <br><br>
                    <button type="submit" class="blue btn center">
                        <i class="material-icons right">save</i>Registrar Empresa
                    </button>

                </div>
                <br>
            </form>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>

    </div>        
</div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QualityMetricsInf\resources\views/admin/addEmpresa.blade.php ENDPATH**/ ?>