

<?php $__env->startSection('title', 'Quality Metrics'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <br><br><br>
        <div class="col s4"></div>
        <div class="col s4 z-depth-2 grey darken-4">   

        <form method="POST" action="<?php echo e(route('add.centro.bd')); ?>">
            <?php echo csrf_field(); ?>

            <div class="col s12 center">
                <br>
                <img src="https://www.qualitymetrics.cl/img/logo-header.png" class="responsive-img">
            </div>
            <div class="col s12">
                <h6 class="white-text center">Registrar centro</h6>
                <br><br><br>
            </div>

            <div class="input-field col s12">
                <select id="empresa" name="empresa" class="browser-default white-text grey darken-4">
                    <option value="" disabled selected>Selecciona una empresa</option>
                    <?php for($i = 0 ; $i < count($empresa) ; $i++): ?>
                        <option value="<?php echo e($empresa[$i]->id); ?>"><?php echo e($empresa[$i]->nombre_empresa); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="input-field col s12">
                <input  id="name" name="name" type="text" class="validate white-text" value="<?php echo e(old('name')); ?>" required autofocus autocomplete="name">
                <label class="white-text" for="name" value="<?php echo e(__('Nombre del centro')); ?>"><?php echo e(__('Nombre del Centro')); ?></label>
            </div>

            <div class="input-field col s12">
                <input  id="ubicacion" name="ubicacion" type="text" class="validate white-text" value="<?php echo e(old('ubicacion')); ?>" required autofocus autocomplete="ubicacion">
                <label class="white-text" for="ubicacion" value="<?php echo e(__('Ubicacion')); ?>"><?php echo e(__('Ubicacion')); ?></label>
            </div>

            <div class="col s12 center">
                <br>
                <button type="submit" class="blue btn center">
                    <i class="material-icons right">save</i>Registrar Centro
                </button>
                <br><br>
            </div>
        </form>
        </div>
    </div>        
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QualityMetricsInf\resources\views/admin/addCentro.blade.php ENDPATH**/ ?>