<style type="text/css">
	table, th, td{
	border: solid black;
    }
</style>
	
<table >
	<thead>
		<tr>
			<th>ID</th>
			<th>SectionCod</th>
			<th>Barcode</th>
			<th>Centro</th>
			<th>Jaula</th>
			<th>Color Entero</th>
			<th>Color Lomo</th>
			<th>Color Belly</th>
			<th>Color NCQ</th>
			<th>Longitud Filete</th>
			<th>Area Filete</th>
			<th>Area Gaping</th>
			<th>Puntos Gaping</th>
			<th>Area Melanosis</th>
			<th>Puntos Melanosis</th>
			<th>Area Hematomas</th>
			<th>Puntos Hematomas</th>
		</tr>
	</thead>
	<tbody>
		<?php for($i = 0 ; $i < 100 ; $i++): ?>
		<tr>
			<td><?php echo e($medicion[$i]->id); ?></td>
			<td><?php echo e($medicion[$i]->sectionCod); ?></td>
			<td><?php echo e($medicion[$i]->barCode); ?></td>
			<td><?php echo e($medicion[$i]->centro); ?></td>
			<td><?php echo e($medicion[$i]->jaula); ?></td>
			<td><?php echo e($medicion[$i]->colorEntero); ?></td>
			<td><?php echo e($medicion[$i]->colorLomo); ?></td>
			<td><?php echo e($medicion[$i]->colorBelly); ?></td>
			<td><?php echo e($medicion[$i]->colorNCQ); ?></td>
			<td><?php echo e($medicion[$i]->longFilete); ?></td>
			<td><?php echo e($medicion[$i]->areaFilete); ?></td>
			<td><?php echo e($medicion[$i]->areaGap); ?></td>
			<td><?php echo e($medicion[$i]->ptosGap); ?></td>
			<td><?php echo e($medicion[$i]->areaMel); ?></td>
			<td><?php echo e($medicion[$i]->ptosMel); ?></td>
			<td><?php echo e($medicion[$i]->areaHem); ?></td>
			<td><?php echo e($medicion[$i]->puntosHem); ?></td>
		</tr>
		<?php endfor; ?>
	</tbody>
</table><?php /**PATH C:\xampp\htdocs\QualityMetricsInf\resources\views/informes/medfiletepdf.blade.php ENDPATH**/ ?>