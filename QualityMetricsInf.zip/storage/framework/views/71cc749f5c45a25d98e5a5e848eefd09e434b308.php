

<?php $__env->startSection('title', 'Quality Metrics'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col s12">
			<h3 class="grey-text grey-darken-1 center">Listado de usuarios registrados en el sistema</h3>

			<?php for($i = 0 ; $i < count($user) ; $i++): ?>

			 <br>
			 <br>
       <div class="card grey darken-4">
        <div class="card-content white-text">
          <span class="card-title"><?php echo e($user[$i]->name); ?></span>
          <?php for($j = 0 ; $j < count($emp) ; $j++): ?>
            <?php if($emp[$j]->id == $user[$i]->empresa): ?>
              <h6 class="white-text"> <?php echo e($emp[$j]->nombre_empresa); ?> </h6>
              <?php endif; ?>
          <?php endfor; ?>
          <h6 class="white-text">Registrado el <?php echo e($user[$i]->created_at); ?> hrs</h6>  
        </div>
        <div class="card-action">
          <?php if($user[$i]->empresa == ""): ?>
            <a class="blue btn modal-trigger" href="#modal<?php echo e($i); ?>"><i class="material-icons right">add</i>Asignar a una empresa</a>
          <?php endif; ?>
          <a class="blue btn"onclick="elimina('<?php echo e($user[$i]->id); ?>')"><i class="material-icons right">delete</i>Eliminar usuario</a>
        </div>
        <div id="modal<?php echo e($i); ?>" class="modal grey darken-4">
          <form method="POST" action="/user/asigna/empresa">
            <input type="text" name="user_id" id="user_id" value="<?php echo e($user[$i]->id); ?>" hidden>
            <?php echo csrf_field(); ?>
            <div class="modal-content">
              <h5 class="white-text">Selecciona una empresa para asignar a <?php echo e($user[$i]->name); ?></h5>
              <select class="browser-default" id="select_empresa" name="select_empresa">
                <?php for( $j = 0 ; $j < count($emp) ; $j++ ): ?>
                  <option value="<?php echo e($emp[$j]->id); ?>"><?php echo e($emp[$j]->nombre_empresa); ?></option>
                <?php endfor; ?>
              </select>
            </div>
            <div class="modal-footer grey darken-3">
              <button type="submit" class="modal-close blue btn" >
                Asignar
              </button>
            </div>            
          </form>
        </div>

      </div>
			 
			<?php endfor; ?>			
		</div>		
	</div>
</div>

<?php $__env->stopSection(); ?>

<script type="text/javascript">
  function elimina(id){
    var opt1 = confirm("¿Está seguro que desea eliminar a este usuario?");
    if(opt1 == true){
      var opt2 = confirm("Esta acción no se puede deshacer, por favor confirme su decisión");

      if(opt2 == true){
        $.get('/user/borra', {id : id}, function(response){
          if(response[0] == "borrado"){
            location.href = "/exito";
          }  
        });
      }
    }

  }
</script>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QualityMetricsInf\resources\views/admin/showUsers.blade.php ENDPATH**/ ?>