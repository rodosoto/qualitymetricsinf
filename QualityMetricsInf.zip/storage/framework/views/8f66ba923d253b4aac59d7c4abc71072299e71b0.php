<?php $__env->startSection('title', 'Quality Metrics'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <br><br><br><br><br><br>
        <div class="col s12">
            <div class="col s3"></div>
            <div class="col s6  z-depth-1">
                <form> 
                    <?php echo csrf_field(); ?>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">mail</i>
                        <input id="mail" type="text" class="validate" name="mail">
                        <label for="mail">Mail</label>
                    </div>
                    <?php $__errorArgs = ['mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br>
                    <small>* <?php echo e($message); ?></small>
                    <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">vpn_key</i>
                        <input id="pass" type="password" class="validate" name="pass">
                        <label for="pass">Contraseña</label>
                    </div>
                    <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br>
                    <small>* <?php echo e($message); ?></small>
                    <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="col s12">
                        <a class="grey darken-2 btn-small right"><i class="material-icons right">chevron_right</i>Ingresar</a>
                    </div>
                </form>
            </div>
            <br> 
            <div class="col s3"></div>
        </div>        
    </div>
</div>
<br><br><br><br><br><br><br> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QualityMetricsInf\resources\views/welcome.blade.php ENDPATH**/ ?>