<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
</head>
<body>
	<div class="row">
		<div class="col s12">
			<div class="col s6">
				<div class="col s12 center">
					<img src="imagenes/fragma.jpg">				
				</div>
				<div class="col s12 center">
					<img src="https://www.qualitymetrics.cl/img/logo-header.png">
				</div>			
			</div>
			<div class="col s6 center">
				<h5 class="blue-text right">MEDICIÓN DE COLOR<br>MELANOSIS, GAPING Y HEMATOMAS<br>USANDO EQUIPO FILLET QUALITY<br>REPORTE N°1<br>
(29 de diciembre al 08 de Enero)</h5>
				
			</div>		
		</div>	
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\QualityMetricsInf\resources\views/informes/reporte.blade.php ENDPATH**/ ?>