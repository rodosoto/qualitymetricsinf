require('./bootstrap');

require('alpinejs');

function construccion(){
	M.toast({html : "Funcion en construccion", classes: "rounded"});
}